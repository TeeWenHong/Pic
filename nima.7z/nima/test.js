const express = require("express");
const path = require("path");
const mongoose = require("mongoose")
mongoose.connect('mongodb://localhost:27017/nima',{
   useNewUrlParser: true ,
   useUnifiedTopology: true
  
})

const app = express();

const User = mongoose.model('User',new mongoose.Schema({
    username:{type:String},
    password:{type:String},
}))

app.use(express.static("public"));
const port = process.env.PORT || 3000;
const ip = "127.0.0.1"

app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "/html/login.html"));
});

app.get("/signin", function (req, res) {
  res.sendFile(path.join(__dirname, "/html/signin.html"));
});

app.get("/pic", function (req, res) {
  res.sendFile(path.join(__dirname, "/html/pic.html"));
});

// app.post('/signin',async(req,res)=>{
//     const user = await User.create({
//         username: req.body.username,
//         password: req.body.password,
//     })
//   console.log（req.body）
//   res.send(user)
// })

app.listen(port);
console.log(`Server started at http://${ip}:` + port);

